// The entry fee's shares (contracts/competition.ts EntryFee): how a fee splits between the bounty's pot and either the
// make.fun fund (fund_percent, a house bounty) or the bounty's creator (creator, a user's or agent's bounty, less
// make.fun's cut of that share, which goes to the fund), and the sentences every surface (server, cli, web) uses to
// tell people and agents about it, with the words for winnings still pending, which never pay a fee. The wording is
// tuned here alone.
//
// Split: fund_cents = floor(fee_cents * fund_percent / 100), pot_cents = fee_cents - fund_cents. With a creator share
// (fund_percent 0): gross = floor(fee_cents * percent / 100), cut = floor(gross * cut_percent / 100), the creator's
// account gets gross - cut, the fund's gets the cut, the pot the rest (fee - gross). A fee is whole cents; in base units
// a cent is 10^(decimals - 2) (USDC: 6 decimals, 10_000 base units a cent).
//
// A leaf: no imports at all, so the server, the cli and the web app all read it.

/** The fund's name as every sentence says it. */
export const FUND_NAME = 'the make.fun fund';

/** What the fund pays for, as every sentence says it (the user's words: more bounties, more content, expansion). */
export const FUND_PURPOSE = "which pays for more bounties, more content and make.fun's expansion";

/**
 * What winnings not cleared to pay yet are (server/entry-fees/eligible.ts EligibleWinnings.pendingCents), as every
 * surface says them: they never pay an entry fee until they are cleared. The insufficient_winnings refusal carries
 * their amount typed (EntryFeeProblem.winnings_pending_usd); these words only say what that amount is.
 */
export const PENDING_WINNINGS_WORDS = 'still pending (under review, held, or awaiting approval)';

/** How every sentence names the person or agent who created a bounty (EntryFee.creator). */
export const CREATOR_NAME = "the bounty's creator";

/**
 * The most of each entry fee a bounty's creator may keep, in percent: the default of server/config.ts
 * sponsorCreatorMaxPercent (MAKEFUN_SPONSOR_CREATOR_MAX_PERCENT).
 */
export const CREATOR_SHARE_MAX_PERCENT = 50;

/**
 * make.fun's cut of a creator's share, in percent of that share, paid to the fund: the default of server/config.ts
 * sponsorCreatorCutPercent (MAKEFUN_SPONSOR_CREATOR_CUT_PERCENT), frozen into each bundle at compose
 * (EntryFee.creator.cut_percent).
 */
export const CREATOR_SHARE_CUT_PERCENT = 15;

/** A creator share's terms (EntryFee.creator without its wallet): its percent of each fee, and make.fun's cut of that share. */
export interface CreatorShareTerms {
  percent: number;
  cut_percent: number;
}

/** Throws unless `p` is an integer 0..100 (`name`: EntryFee.fund_percent unless named). */
function assertPercent(p: number, name = 'fund_percent'): void {
  if (!Number.isInteger(p) || p < 0 || p > 100) throw new RangeError(`${name} ${p} is not an integer 0..100`);
}

/** Throws unless `c` holds a creator share: percent an integer 1..100, cut_percent an integer 0..100. */
function assertCreator(c: CreatorShareTerms): void {
  if (!Number.isInteger(c.percent) || c.percent < 1 || c.percent > 100) throw new RangeError(`creator percent ${c.percent} is not an integer 1..100`);
  assertPercent(c.cut_percent, 'creator cut_percent');
}

/** The fee's fund percent: its fund_percent, 0 when absent (or no fee at all). */
export function fundPercentOf(entryFee: { fund_percent?: number } | null | undefined): number {
  return entryFee?.fund_percent ?? 0;
}

/** The fee's creator share terms (its creator, the wallet dropped), null when it has none (or no fee at all). */
export function creatorTermsOf(entryFee: { creator?: CreatorShareTerms } | null | undefined): CreatorShareTerms | null {
  const c = entryFee?.creator;
  return c === undefined ? null : { percent: c.percent, cut_percent: c.cut_percent };
}

/**
 * A fee of `feeCents` (a whole number of cents, 0 or more) split at `fundPercent`, or with `creator` (fundPercent then
 * 0): fund_cents is what reaches the fund's account (the fund share, or make.fun's cut of the creator's share),
 * creator_cents what reaches the creator's account, pot_cents the rest; every share rounded down to the cent, and
 * pot_cents + fund_cents + creator_cents = feeCents. Throws on a fee that is not whole cents, a percent out of range,
 * or a fund percent above 0 beside a creator share.
 */
export function entryFeeSplitCents(
  feeCents: number,
  fundPercent: number,
  creator: CreatorShareTerms | null = null,
): { pot_cents: number; fund_cents: number; creator_cents: number; creator_cut_cents: number } {
  if (!Number.isSafeInteger(feeCents) || feeCents < 0) throw new RangeError(`fee ${feeCents} is not a whole number of cents`);
  assertPercent(fundPercent);
  if (creator === null) {
    const fund_cents = Number((BigInt(feeCents) * BigInt(fundPercent)) / 100n);
    return { pot_cents: feeCents - fund_cents, fund_cents, creator_cents: 0, creator_cut_cents: 0 };
  }
  assertCreator(creator);
  if (fundPercent !== 0) throw new RangeError(`fund_percent ${fundPercent} beside a creator share: a fee sends a share to the make.fun fund or to the bounty's creator, never both`);
  const gross = (BigInt(feeCents) * BigInt(creator.percent)) / 100n;
  const cut = (gross * BigInt(creator.cut_percent)) / 100n;
  return { pot_cents: feeCents - Number(gross), fund_cents: Number(cut), creator_cents: Number(gross - cut), creator_cut_cents: Number(cut) };
}

/**
 * A fee of `feeBaseUnits` (a token with `decimals` decimals) split at `fundPercent` or with `creator`, in whole cents
 * as entryFeeSplitCents splits it: fund what reaches the fund's account, creator what reaches the creator's,
 * creator_cut make.fun's cut of the creator's share (inside fund), pot the rest. Throws on decimals under 2 (or not an
 * integer), a negative fee, a fee that is not whole cents, a percent out of range, or a fund percent above 0 beside a
 * creator share.
 */
export function entryFeeSplitBaseUnits(
  feeBaseUnits: bigint,
  fundPercent: number,
  decimals: number,
  creator: CreatorShareTerms | null = null,
): { pot: bigint; fund: bigint; creator: bigint; creator_cut: bigint } {
  if (!Number.isInteger(decimals) || decimals < 2) throw new RangeError(`decimals ${decimals}: a cent needs 2 or more`);
  if (feeBaseUnits < 0n) throw new RangeError(`fee ${feeBaseUnits} base units is negative`);
  assertPercent(fundPercent);
  const cent = 10n ** BigInt(decimals - 2);
  if (feeBaseUnits % cent !== 0n) throw new RangeError(`fee ${feeBaseUnits} base units is not whole cents at ${decimals} decimals`);
  const cents = feeBaseUnits / cent;
  if (creator === null) {
    const fund = ((cents * BigInt(fundPercent)) / 100n) * cent;
    return { pot: feeBaseUnits - fund, fund, creator: 0n, creator_cut: 0n };
  }
  assertCreator(creator);
  if (fundPercent !== 0) throw new RangeError(`fund_percent ${fundPercent} beside a creator share: a fee sends a share to the make.fun fund or to the bounty's creator, never both`);
  const gross = (cents * BigInt(creator.percent)) / 100n;
  const cut = (gross * BigInt(creator.cut_percent)) / 100n;
  return { pot: feeBaseUnits - gross * cent, fund: cut * cent, creator: (gross - cut) * cent, creator_cut: cut * cent };
}

/** Where the fee goes, as one sentence: null at 0 (the whole fee joins the pot, as always). */
export function fundShareSentence(fundPercent: number): string | null {
  assertPercent(fundPercent);
  if (fundPercent === 0) return null;
  if (fundPercent === 100) return `The whole entry fee goes to ${FUND_NAME}, ${FUND_PURPOSE}; none of it joins this bounty's pot.`;
  return `${fundPercent}% of the entry fee goes to ${FUND_NAME}, ${FUND_PURPOSE}; the other ${100 - fundPercent}% joins this bounty's pot.`;
}

/** What a no-place refund returns, as one sentence: null at 0 (the whole fee is refunded). */
export function fundRefundSentence(fundPercent: number): string | null {
  assertPercent(fundPercent);
  if (fundPercent === 0) return null;
  if (fundPercent === 100) return 'None of it is refunded if nobody places.';
  return "The fund's share is never refunded: if nobody places, only the pot's share comes back.";
}

/** Where a creator bounty's fee goes, as one sentence: the creator's share, make.fun's cut of it (when any), and the pot's. */
export function creatorShareSentence(c: CreatorShareTerms): string {
  assertCreator(c);
  const cut = c.cut_percent === 0 ? '' : `, less make.fun's ${c.cut_percent}% cut of that share, which goes to ${FUND_NAME}`;
  if (c.percent === 100) return `The whole entry fee goes to ${CREATOR_NAME}${cut}; none of it joins this bounty's pot.`;
  return `${c.percent}% of the entry fee goes to ${CREATOR_NAME}${cut}; the other ${100 - c.percent}% joins this bounty's pot.`;
}

/**
 * What a no-place refund returns on a creator bounty, as one sentence: the creator's share (and make.fun's cut of it)
 * is never refunded. At `percent` 100 nothing is.
 */
export function creatorRefundSentence(percent?: number): string {
  if (percent === 100) return 'None of it is refunded if nobody places.';
  return "The creator's share is never refunded: if nobody places, only the pot's share comes back.";
}

/** The creator's share beside a fee on a dock or a band ('40% to the creator'), as src/lib/bounty.ts fundShareTag says the fund's. */
export function creatorShareTag(percent: number): string {
  return `${percent}% to the creator`;
}

/**
 * The sentences for a fee's shares, whichever it has: the creator's (creatorShareSentence, creatorRefundSentence) or
 * the fund's (fundShareSentence, fundRefundSentence); both null when the whole fee joins the pot (or no fee at all).
 * Every new surface calls this one.
 */
export function feeShareSentences(entryFee: { fund_percent?: number; creator?: CreatorShareTerms } | null | undefined): { share: string | null; refund: string | null } {
  const creator = creatorTermsOf(entryFee);
  if (creator !== null) return { share: creatorShareSentence(creator), refund: creatorRefundSentence(creator.percent) };
  const fund = fundPercentOf(entryFee);
  return { share: fundShareSentence(fund), refund: fundRefundSentence(fund) };
}
